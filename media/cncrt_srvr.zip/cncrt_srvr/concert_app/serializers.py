from rest_framework import serializers
from concert_app.models import MusicGroup
from django.contrib.auth.models import User


class ConcertSerializer(serializers.ModelSerializer):
    owner = serializers.ReadOnlyField(source='owner.username')

    class Meta:
        model = MusicGroup
        fields = ('id', 'artist', 'location', 'location_desc', 'concert_details', 'xlat', 'ylong', 'genreid', 'logo', 'owner', 'datetime', 'created')


class UserSerializer(serializers.ModelSerializer):
    concert = serializers.PrimaryKeyRelatedField(many=True, queryset=MusicGroup.objects.all())

    class Meta:
        model = User
        fields = ('id', 'username', 'concert')