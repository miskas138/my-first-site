from django.db import models

LOCATION_CHOICES = [('Αρτας','ΑΡΤΑΣ'),('Έβρου','ΕΒΡΟΥ'),('Αιτωλίας και Ακαρνανίας','ΑΙΤΩΛΙΑΣ ΚΑΙ ΑΚΑΡΝΑΝΙΑΣ'),('Αργολίδας','ΑΡΓΟΛΙΔΑΣ'),('Αρκαδίας','ΑΡΚΑΔΙΑΣ'),('Αττικής','ΑΤΤΙΚΗΣ'),('Αχαΐας','ΑΧΑΪΑΣ'),('Βοιωτίας','ΒΟΙΩΤΙΑΣ'),('Γρεβενών','ΓΡΕΒΕΝΩΝ'),('Δράμας','ΔΡΑΜΑΣ'),('Δωδεκανήσου','ΔΩΔΕΚΑΝΗΣΟΥ'),('Ευρυτανίας','ΕΥΡΥΤΑΝΙΑΣ'),('Εύβοιας','ΕΥΒΟΙΑΣ'),('Ζακύνθου','ΖΑΚΥΝΘΟΥ'),('Ηλείας','ΗΛΕΙΑΣ'),('Ημαθίας','ΗΜΑΘΙΑΣ'),('Ηρακλείου','ΗΡΑΚΛΕΙΟΥ'),('Θεσπρωτίας','ΘΕΣΠΡΩΤΙΑΣ'),('Θεσσαλονίκης','ΘΕΣΣΑΛΟΝΙΚΗΣ'),('Ιωαννίνων','ΙΩΑΝΝΙΝΩΝ'),('Κέρκυρας','ΚΕΡΚΥΡΑΣ'),('Καβάλας','ΚΑΒΑΛΑΣ'),('Καρδίτσας','ΚΑΡΔΙΤΣΑΣ'),('Καστοριάς','ΚΑΣΤΟΡΙΑΣ'),('Κεφαλληνίας','ΚΕΦΑΛΛΗΝΙΑΣ'),('Κιλκίς','ΚΙΛΚΙΣ'),('Κοζάνης','ΚΟΖΑΝΗΣ'),('Κορινθίας','ΚΟΡΙΝΘΙΑΣ'),('Κυκλάδων','ΚΥΚΛΑΔΩΝ'),('Λάρισας','ΛΑΡΙΣΑΣ'),('Λέσβου','ΛΕΣΒΟΥ'),('Λακωνίας','ΛΑΚΩΝΙΑΣ'),('Λασιθίου','ΛΑΣΙΘΙΟΥ'),('Λευκάδας','ΛΕΥΚΑΔΑΣ'),('Μαγνησίας','ΜΑΓΝΗΣΙΑΣ'),('Μεσσηνίας','ΜΕΣΣΗΝΙΑΣ'),('Ξάνθης','ΞΑΝΘΗΣ'),('Πέλλας','ΠΕΛΛΑΣ'),('Πιερίας','ΠΙΕΡΙΑΣ'),('Πρέβεζας','ΠΡΕΒΕΖΑΣ'),('Ρεθύμνου','ΡΕΘΥΜΝΟΥ'),('Ροδόπης','ΡΟΔΟΠΗΣ'),('Σάμου','ΣΑΜΟΥ'),('Σερρών','ΣΕΡΡΩΝ'),('Τρικάλων','ΤΡΙΚΑΛΩΝ'),('Φθιώτιδας','ΦΘΙΩΤΙΔΑς'),('Φλώρινας','ΦΛΩΡΙΝΑΣ'),('Φωκίδας','ΦΩΚΙΔΑΣ'),('Χίου','ΧΙΟΥ'),('Χαλκιδικής','ΧΑΛΚΙΔΙΚΗΣ'),('Χανίων','ΧΑΝΙΩΝ')]
GENRE_ID = [('0', 'All'), ('1', 'Rock'), ('2', 'Metal'),('3', 'Punk'), ('4', 'Rockabilly'), ('5', 'Psychobilly'), ('6', 'Rock and Roll'), ('7', 'Surf'), ('8', 'Hard Core'), ('9', 'Hard Rock'), ('10', 'Alternative'), ('11', 'Grudge'), ('12', 'Proressive'), ('13', 'Experimental')]

class MusicGroup(models.Model):
    created = models.DateTimeField(auto_now_add=True)
    artist = models.CharField(max_length=250)
    genreid = models.CharField(choices=GENRE_ID, default=0, max_length=100)
    logo =  models.ImageField()

    datetime = models.DateTimeField(auto_now_add=False, blank=False)
    location = models.CharField(choices=LOCATION_CHOICES, default='Θεσσαλονίκης', max_length=100)
    location_desc = models.CharField(max_length=1000)
    concert_details = models.CharField(max_length=1000, blank=True)
    xlat = models.FloatField('Χ latitude', blank=True, default=None, null=True)
    ylong = models.FloatField('Y longitude', blank=True, default=None, null=True)
    owner = models.ForeignKey('auth.User', related_name='concert', null=True)

    # handles the print at $python manage.py shell
    # when the user types:
    # >>>from concert.models import MusicGroup'',''Event
    # >>>MusicGroup.objects.all()
    def __str__(self):
        return self.artist + '-' + self.get_genreid_display()

    class Meta:
        ordering = ('created',)

