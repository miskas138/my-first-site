from django.contrib import admin
from django.contrib.auth.models import User

from .models import MusicGroup
from django.contrib.admin import AdminSite

#root
#toor1234
class MusicGroup_Admin(admin.ModelAdmin):
    list_display = ('created', 'artist', 'genreid', 'logo', 'datetime', 'location', 'location_desc', 'concert_details', 'xlat', 'ylong', 'owner')
    list_filter = ('created', 'artist', 'genreid', 'logo', 'datetime', 'location', 'location_desc', 'concert_details', 'xlat', 'ylong', 'owner')
    search_fields = ('created', 'artist', 'genreid', 'logo', 'datetime', 'location', 'location_desc', 'concert_details', 'xlat', 'ylong', 'owner')
    list_editable = ('artist', 'genreid', 'logo', 'datetime', 'location', 'location_desc', 'concert_details', 'xlat', 'ylong', 'owner')

class User_Admin(admin.ModelAdmin):
    list_display = ('username', 'first_name', 'last_name', 'email', 'date_joined', 'is_active', 'is_staff')
    list_display_links = ('username','first_name', 'last_name', 'email', 'date_joined', 'is_active', 'is_staff')

    list_filter = ('username','first_name', 'last_name', 'email', 'date_joined', 'is_active', 'is_staff')
    search_fields = ('username','first_name', 'last_name', 'email', 'date_joined', 'is_active', 'is_staff')


class My_Admin(AdminSite): #override Admin site, και αλλαγή
    site_header = 'Concert Finder Site Administration' #τίτλου και επικεφαλίδας.
    site_title = 'Concert Finder'


admin.site= My_Admin(name='my_admin')
admin.site.register(MusicGroup, MusicGroup_Admin)
admin.site.register(User, User_Admin)