from django.apps import AppConfig


class ConcertAppConfig(AppConfig):
    name = 'concert_app'
