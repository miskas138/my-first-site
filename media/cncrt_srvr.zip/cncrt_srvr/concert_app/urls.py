from django.conf.urls import  url

from concert_app import views


urlpatterns = [
    #/concert
    url(r'^$',views.ConcertList.as_view()),
    url(r'^(?P<pk>[0-9]+)/$', views.ConcertDetail.as_view()),

]
