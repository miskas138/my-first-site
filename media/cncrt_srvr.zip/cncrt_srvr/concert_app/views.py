from django.utils import timezone

from concert_app.models import MusicGroup
from concert_app.serializers import ConcertSerializer
from rest_framework import generics
from rest_framework import filters
from django.contrib.auth.models import User
from concert_app.serializers import UserSerializer
from rest_framework import permissions
from concert_app.permissions import IsOwnerOrReadOnly
import rest_framework_filters as filter

class UserList(generics.ListAPIView):
    queryset = User.objects.all()
    serializer_class = UserSerializer


class UserDetail(generics.RetrieveAPIView):
    queryset = User.objects.all()
    serializer_class = UserSerializer




class ConcertListFilter(filter.FilterSet):
    datetime = filter.AllLookupsFilter(name='datetime')
    genreid = filter.AllLookupsFilter(name='genreid')
    artist = filter.AllLookupsFilter(name='artist')
    location = filter.AllLookupsFilter(name='location')
    location_desc = filter.AllLookupsFilter(name='location_desc')
    concert_details = filter.AllLookupsFilter(name='concert_details')
    owner = filter.AllLookupsFilter(name='owner')
    created = filter.AllLookupsFilter(name='created')
    class Meta:
        model = MusicGroup
        fields = ('datetime', 'genreid', 'artist', 'location', 'location_desc', 'concert_details', 'owner', 'created')

class ConcertList(generics.ListCreateAPIView):
    """
    Returns a list of all snippets.
    For more details on snippets please [see here][ref].
    [ref]: http://example.com/
    """
    permission_classes = (permissions.IsAuthenticatedOrReadOnly,)
    queryset = MusicGroup.objects.filter(datetime__lte=timezone.now()).order_by('-datetime')

    serializer_class = ConcertSerializer
    filter_backends = (filters.DjangoFilterBackend,filters.SearchFilter, filters.OrderingFilter,)
    filter_fields = ('created', 'datetime', 'genreid', 'artist', 'location', 'location_desc', 'owner')
    search_fields = ('genreid', 'artist', 'location', 'datetime', 'owner', 'location_desc', 'created')
    ordering_fields = ('created', 'datetime', 'owner', 'genreid', 'artist', 'location')

    filter_class = ConcertListFilter

    def perform_create(self, serializer):
        serializer.save(owner=self.request.user)


class ConcertDetail(generics.RetrieveUpdateDestroyAPIView):
    permission_classes = (permissions.IsAuthenticatedOrReadOnly, IsOwnerOrReadOnly,)
    queryset = MusicGroup.objects.all()
    serializer_class = ConcertSerializer
